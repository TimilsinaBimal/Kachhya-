package com.example.prati.kachhya;

public class Data_Teacher {

    public String fname, lname, phoneNumber, email, depart,gender;

    public Data_Teacher() {

    }

    public Data_Teacher(String fname, String lname, String phoneNumber, String email, String depart,String gender) {
        this.fname = fname;
        this.lname = lname;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.depart = depart;
        this.gender = gender;
    }
}
